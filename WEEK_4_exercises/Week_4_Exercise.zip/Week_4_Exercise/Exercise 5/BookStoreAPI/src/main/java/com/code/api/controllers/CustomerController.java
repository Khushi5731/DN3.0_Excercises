package com.code.api.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.code.api.entity.Customer;
import com.code.api.services.CustomerService;

@Controller
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping("/test")
    public String test() {
        return "welcome";
    }

    @GetMapping("/register")
    public String getRegister(Model model) {
        model.addAttribute("customer", new Customer());
        return "registration";
    }

    @PostMapping("/save")
    public String registerCustomer(@ModelAttribute("customer") Customer customer) {
        customerService.addCustomer(customer);
        return "registration";
    }
}
